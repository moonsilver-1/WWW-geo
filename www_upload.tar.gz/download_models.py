"""Download pinned public checkpoints into the dedicated project directory."""
import json
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download

ROOT = Path(__file__).resolve().parent
MODELS = {'qwen3vl8b': 'Qwen/Qwen3-VL-8B-Instruct',
          'internvl35_8b': 'OpenGVLab/InternVL3_5-8B-HF'}


def main():
    manifest = {}
    for key, repo in MODELS.items():
        target = ROOT/'models'/key
        if (target/'download_complete.json').exists():
            manifest[key] = json.loads((target/'download_complete.json').read_text())
            continue
        revision = HfApi().model_info(repo).sha
        print(f'Downloading {key}; pinned revision {revision}', flush=True)
        snapshot_download(repo, revision=revision, local_dir=target, max_workers=4,
                          allow_patterns=['*.json', '*.jinja', '*.txt', '*.model', '*.safetensors', '*.py'])
        manifest[key] = {'repository': repo, 'revision': revision, 'path': f'models/{key}'}
        (target/'download_complete.json').write_text(json.dumps(manifest[key], indent=2)+'\n')
        (ROOT/'models'/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
        print(f'Ready: {key}', flush=True)
    (ROOT/'models'/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')


if __name__ == '__main__':
    main()
