"""Pinned-model, fact-matched Web evidence inference on archived page states.

The displayed --device records the physical GPU selected by the queue; a UUID
visibility mask maps it to runtime cuda:0. Both channels target one exact fact.
Raw responses, parse failures and both scoring spans remain in the archive.
"""
import argparse
from collections import Counter
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import sys
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE if (HERE/'src').exists() else HERE.parents[1]
sys.path[:0] = [str(ROOT/'src'/'blackbox_eval'), str(ROOT/'src'/'evidence_state')]


def parse_credit(text):
    match = re.search(r'\{[^{}]*\}', text)
    try:
        data = json.loads(match.group()) if match else {}
        expected = {f'EV-{i}' for i in range(1, 7)}
        if set(data) != expected or any(isinstance(x, bool) or not isinstance(x, (int, float))
                                       or not 0 <= x <= 1 for x in data.values()):
            return None, False
        return [float(data[f'EV-{i}']) for i in range(1, 7)], True
    except (ValueError, AttributeError):
        return None, False


def neutralize(blocks, state):
    from p0_data import neutral_text
    from PIL import Image, ImageFilter
    out = []
    for b, present in zip(blocks, state):
        item = dict(b)
        if present < 0:
            if b['type'] in ('I', 'C'):
                image = Path(b['image']); target = image.with_name(image.stem+'_neutral.png')
                if not target.exists():
                    tmp = target.with_name(target.stem+f'.{os.getpid()}.tmp.png')
                    with Image.open(image) as im:
                        im.convert('RGB').filter(ImageFilter.GaussianBlur(12)).save(tmp)
                    os.replace(tmp, target)
                item['image'] = str(target)
            else:
                base = b['text'][:400]
                item['text'] = neutral_text(base if len(base) > 60 else base+' '*(60-len(base)))
        out.append(item)
    return out


class Reader:
    def __init__(self, key, device):
        import torch
        from transformers import AutoProcessor, AutoModelForImageTextToText
        from transformers import Qwen3VLForConditionalGeneration
        self.torch = torch
        self.metadata = json.loads((ROOT/'models'/key/'download_complete.json').read_text())
        model = str(ROOT/self.metadata['path'])
        self.processor = AutoProcessor.from_pretrained(model, local_files_only=True, trust_remote_code=True)
        # Match the established image budget for the Qwen processor.
        if key == 'qwen3vl8b':
            self.processor.image_processor.min_pixels = 256*28*28
            self.processor.image_processor.max_pixels = 768*28*28
        cls = Qwen3VLForConditionalGeneration if key == 'qwen3vl8b' else AutoModelForImageTextToText
        self.model = cls.from_pretrained(model, torch_dtype=torch.bfloat16,
                                        attn_implementation='sdpa', local_files_only=True,
                                        trust_remote_code=True).to(device).eval()
        self.device = device

    def inputs(self, messages, add_generation_prompt):
        from PIL import Image
        text = self.processor.apply_chat_template(messages, tokenize=False,
                                                  add_generation_prompt=add_generation_prompt,
                                                  enable_thinking=False)
        images = []
        for message in messages:
            if isinstance(message['content'], list):
                for item in message['content']:
                    if item.get('type') == 'image':
                        with Image.open(item['image']) as im:
                            images.append(im.convert('RGB'))
        return self.processor(text=[text], images=images or None, return_tensors='pt').to(self.device)

    def generate(self, blocks, question, system=None, suffix=None):
        from engines import blocks_to_messages
        enc = self.inputs(blocks_to_messages(blocks, question, system=system, suffix=suffix), True)
        with self.torch.inference_mode():
            output = self.model.generate(**enc, max_new_tokens=200, do_sample=False)
        return self.processor.tokenizer.decode(output[0, enc.input_ids.shape[1]:], skip_special_tokens=True).strip()

    def score(self, blocks, question, statement):
        from engines import blocks_to_messages
        enc = self.inputs(blocks_to_messages(blocks, question, statement), False)
        prefix = self.inputs(blocks_to_messages(blocks, question), True)
        n_prefix = prefix.input_ids.shape[1]
        assert self.torch.equal(enc.input_ids[0, :n_prefix], prefix.input_ids[0]), 'Unaligned assistant prefix'
        answer_ids = enc.input_ids[0, n_prefix:]
        ref_ids = self.processor.tokenizer(statement, add_special_tokens=False)['input_ids']
        n_ref = len(ref_ids)
        assert answer_ids[:n_ref].tolist() == ref_ids, 'Reference span tokenization differs at boundary'
        with self.torch.inference_mode():
            logits = self.model(**enc).logits[0, n_prefix-1:enc.input_ids.shape[1]-1].float()
            lp = self.torch.log_softmax(logits, -1).gather(1, answer_ids[:, None]).squeeze(1)
        return {'A_j': float(lp.mean()), 'A_reference': float(lp[:n_ref].mean()),
                'n_response_tokens': len(answer_ids), 'n_reference_tokens': n_ref,
                'response_token_ids': answer_ids.tolist()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True, choices=['qwen3vl8b', 'internvl35_8b'])
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--pages', default='all')
    ap.add_argument('--limit-states', type=int, default=0)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()
    from realweb_data import SPEC as development
    from realweb_extension import SPEC as transfer, build_blocks
    from run_realweb import build_blocks_real
    from run_absolute_control import NOCTX_SYSTEM, NOCTX_SUFFIX
    specs = {**development, **transfer}
    selected = list(specs) if args.pages == 'all' else args.pages.split(',')
    assert set(selected) <= set(specs)
    work = [(page, state) for page in selected for state in itertools.product((-1, 1), repeat=6)]
    if args.limit_states:
        work = work[:args.limit_states]
    data_hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                   for folder in [ROOT/'data'/'realweb', ROOT/'data'/'realweb_extension']
                   for p in folder.rglob('*') if p.is_file()}
    destination = ROOT/'results'/'www'; destination.mkdir(parents=True, exist_ok=True)
    output = destination/f'{args.model}.jsonl'
    previous = [json.loads(line) for line in output.read_text().splitlines()] if output.exists() else []
    done = {(r['page'], tuple(r['state'])) for r in previous if r.get('parse_ok') and 'A_j' in r}
    work = [(p, s) for p, s in work if (p, s) not in done]
    if args.dry_run:
        for page in selected:
            blocks = build_blocks_real(page, [1]*6) if page in development else build_blocks(page)
            assert len(blocks) == 6
            assert all(Path(b['image']).exists() for b in blocks if b['type'] in ('I', 'C'))
        print(f'{len(selected)} pages; {len(work)} pending states; all assets found', flush=True)
        return
    if os.environ.get('CUDA_VISIBLE_DEVICES'):
        occupied = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid',
                                            '--format=csv,noheader'], text=True).splitlines()
        if os.environ['CUDA_VISIBLE_DEVICES'] in {x.strip() for x in occupied}:
            print('Selected GPU acquired another task before loading; retry later', flush=True)
            raise SystemExit(75)
    import torch
    torch.set_num_threads(args.workers)
    runtime_device = 'cuda:0' if os.environ.get('CUDA_VISIBLE_DEVICES') else args.device
    reader = Reader(args.model, runtime_device)
    (destination/f'{args.model}_manifest.json').write_text(json.dumps({'model': reader.metadata,
         'source_sha256': data_hashes, 'protocol': 'experiments/www/protocol.md',
         'physical_device': args.device, 'visible_uuid': os.environ.get('CUDA_VISIBLE_DEVICES'),
         'torch': torch.__version__, 'legacy_score': 'entire assistant response including chat terminator',
         'reference_score': 'reference-statement tokens only'}, indent=2)+'\n')
    started = time.time()
    print(f'{args.model}: {len(work)} pending states on {args.device}', flush=True)
    for index, (page, state) in enumerate(work, 1):
        spec = specs[page]; question = spec.get('question', spec.get('query')); statement = spec['statement']
        record = {'engine': args.model, 'checkpoint': reader.metadata['repository'],
                  'revision': reader.metadata['revision'], 'page': page, 'state': list(state),
                  'question': question, 'statement': statement,
                  'split': 'development' if page in development else 'transfer'}
        try:
            blocks = build_blocks_real(page, list(state)) if page in development else build_blocks(page)
            blocks = neutralize(blocks, state)
            record.update(reader.score(blocks, question, statement))
            raw = reader.generate(blocks, question, system=NOCTX_SYSTEM, suffix=NOCTX_SUFFIX.format(ans=statement))
            scores, valid = parse_credit(raw)
            record.update({'gen': raw, 'p': scores, 'parse_ok': valid})
            if all(s == 1 for s in state):
                record['answer_generation'] = reader.generate(blocks, question)
        except Exception as exc:
            record.update({'parse_ok': False, 'error': f'{type(exc).__name__}: {exc}'})
        record['elapsed'] = time.time()-started
        with output.open('a') as handle:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False)+'\n'); handle.flush()
        if index == 1 or index % 16 == 0:
            print(f'{index}/{len(work)} {page} parse={record["parse_ok"]} error={record.get("error", "none")} elapsed={record["elapsed"]:.0f}s', flush=True)
        if 'OutOfMemoryError' in record.get('error', ''):
            raise RuntimeError('GPU memory budget exceeded; inspect log before retrying')
        if index <= 2 and 'error' in record:
            raise RuntimeError('Initial model/scoring validation failed; inspect logged error')
    rows = [json.loads(line) for line in output.read_text().splitlines()]
    unique = {(r['page'], tuple(r['state'])): r for r in rows if r.get('parse_ok') and 'A_j' in r}
    counts = Counter(r['page'] for r in unique.values())
    report = {'pages': len(selected), 'eligible_cubes': sum(counts[p] == 64 for p in selected),
              'parsed_state_counts': dict(counts), 'raw_rows': len(rows)}
    (destination/f'{args.model}_completion.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
