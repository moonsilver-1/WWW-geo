"""Run resumable inference only after three clean GPU observations.

An idle GPU has no compute processes, <=512 MiB used, and <=3% utilization.
Per-device advisory locks coordinate this project; fresh driver observations
check other users immediately before each launch. No foreign tasks are changed.
"""
import argparse
import csv
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
JOBS = ['qwen3vl8b', 'internvl35_8b']


def snapshot():
    text = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,memory.used,utilization.gpu',
                                    '--format=csv,noheader,nounits'], text=True)
    processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid',
                                         '--format=csv,noheader,nounits'], text=True)
    occupied = {r[0].strip() for r in csv.reader(processes.splitlines()) if r}
    return [{'index': int(r[0]), 'uuid': r[1].strip(), 'memory_mib': int(r[2]),
             'utilization': int(r[3]), 'idle': r[1].strip() not in occupied and int(r[2]) <= 512 and int(r[3]) <= 3}
            for r in csv.reader(text.splitlines()) if r]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--poll-seconds', type=int, default=30)
    ap.add_argument('--idle-samples', type=int, default=3)
    args = ap.parse_args()
    os.chdir(ROOT)
    (ROOT/'locks').mkdir(exist_ok=True); (ROOT/'logs').mkdir(exist_ok=True)
    coordinator = (ROOT/'locks'/'queue.lock').open('w')
    fcntl.flock(coordinator, fcntl.LOCK_EX|fcntl.LOCK_NB)
    state_path = ROOT/'results'/'www'/'queue_state.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else {}
    stable, running = {}, {}
    try:
        while True:
            observed = snapshot()
            for gpu in observed:
                stable[gpu['uuid']] = stable.get(gpu['uuid'], 0)+1 if gpu['idle'] else 0
            for key, item in list(running.items()):
                code = item['process'].poll()
                if code is None:
                    continue
                state[key].update({'status': 'complete' if code == 0 else 'failed', 'exit_code': code})
                item['log'].close(); item['lock'].close(); del running[key]
            pending = [j for j in JOBS if j not in running and state.get(j, {}).get('status') != 'complete'
                       and state.get(j, {}).get('attempts', 0) < 2]
            for key in pending:
                available = [g for g in observed if g['idle'] and stable[g['uuid']] >= args.idle_samples]
                if not available:
                    break
                gpu = available[0]
                lock = (ROOT/'locks'/f"gpu_{gpu['index']}.lock").open('w')
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
                    if not any(g['uuid'] == gpu['uuid'] and g['idle'] for g in snapshot()):
                        lock.close(); continue
                except BlockingIOError:
                    lock.close(); continue
                subprocess.run(['nvitop', '--once', '--ascii', '--readonly'], stdout=(ROOT/'logs'/'nvitop_before_launch.txt').open('w'), check=True)
                env = dict(os.environ, CUDA_DEVICE_ORDER='PCI_BUS_ID', CUDA_VISIBLE_DEVICES=gpu['uuid'],
                           TOKENIZERS_PARALLELISM='false', OMP_NUM_THREADS='4')
                command = ['python', '-u', 'run_web_eval.py', '--model', key,
                           '--device', f"cuda:{gpu['index']}", '--workers', '4']
                log = (ROOT/'logs'/f'{key}.log').open('a')
                process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                state[key] = {'status': 'running', 'pid': process.pid, 'gpu': gpu['index'],
                              'gpu_uuid': gpu['uuid'], 'command': ' '.join(command),
                              'attempts': state.get(key, {}).get('attempts', 0)+1, 'started_at_unix': time.time()}
                running[key] = {'process': process, 'lock': lock, 'log': log}
                print(f"Launched {' '.join(command)} (PID {process.pid})", flush=True)
                stable[gpu['uuid']] = 0; gpu['idle'] = False
            status = {'jobs': state, 'gpus': observed, 'observed_at_unix': time.time()}
            # Persist jobs separately from each driver snapshot for easy resumption.
            tmp = state_path.with_suffix('.tmp'); tmp.write_text(json.dumps(state, indent=2)+'\n'); tmp.replace(state_path)
            (ROOT/'results'/'www'/'gpu_status.json').write_text(json.dumps(status, indent=2)+'\n')
            print('GPU check: '+', '.join(f"{g['index']}={'idle' if g['idle'] else 'busy'}" for g in observed), flush=True)
            if not pending and not running:
                break
            time.sleep(args.poll_seconds)
    finally:
        coordinator.close()


if __name__ == '__main__':
    main()
